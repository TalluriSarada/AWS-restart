print("Hello World")
myValue=1
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))
myValue1=3.14
print(myValue1)
print(type(myValue1))
myValue2=5j
print(myValue2)
print(type(myValue2))
myValue3=True
print(myValue3)
print(type(myValue3))
myValue4=True
print(myValue4)
print(type(myValue4))
